

#Pregunta 4.
##########################################################
'''
Creat una tabla llamada record_estudiante cuyos campos son:
rec_codigo, rec_nombres, rec_apellidos, rec_nacademica, rec_ntesis, rec_npromedio, rec_indicador
Considere mensajes messagebox para notificar si la tabla ha sido creada

'''
##########################################################
#Pregunta 5
'''
Mediante Tkinter el sistema debe crear un menú para insertar y consultar información del record Acádemico
Cree botones para hacer el llamado a la ventana
De estilo a las tablas
'''

##########################################################
import tkinter as tk
from tkinter import messagebox as mb
import sys
import sqlite3


class Instituto:
    def __init__(self):
        
        
        self.ventana1=tk.Tk()
        self.ventana1.geometry("600x550")
        self.ventana1.title("Sistema de Notas")
               
        self.agregar_menu()
        imagen = tk.PhotoImage(file="ismac.png")
        tk.Label(master=self.ventana1, image=imagen, bd=0, width=300, height=300).pack(side="top")

     
        self.ventana1.mainloop()
    

    def agregar_menu(self):
        self.menubar1 = tk.Menu(self.ventana1)
        self.ventana1.config(menu=self.menubar1)
        self.opciones1 = tk.Menu(self.menubar1, tearoff=0)
 



vinstituto=Instituto() 