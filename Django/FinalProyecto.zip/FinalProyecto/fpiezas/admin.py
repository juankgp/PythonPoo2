from django.contrib import admin
from fpiezas.models import *
# Register your models here.
admin.site.register(Piezas)

admin.site.register(Proveedor)

admin.site.register(Suministra)
# Register your models here.
