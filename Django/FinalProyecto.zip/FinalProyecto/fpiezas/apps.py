from django.apps import AppConfig


class FpiezasConfig(AppConfig):
    name = 'fpiezas'
