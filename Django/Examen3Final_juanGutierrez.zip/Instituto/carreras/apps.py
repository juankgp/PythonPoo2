from django.apps import AppConfig


class CarrerasConfig(AppConfig):
    name = 'carreras'
