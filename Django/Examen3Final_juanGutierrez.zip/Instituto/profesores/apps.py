from django.apps import AppConfig


class ProfesoresConfig(AppConfig):
    name = 'profesores'
