from django.apps import AppConfig


class EstudiantesConfig(AppConfig):
    name = 'estudiantes'
