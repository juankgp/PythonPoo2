from django.apps import AppConfig


class PagosConfig(AppConfig):
    name = 'pagos'
