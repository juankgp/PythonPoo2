from django.apps import AppConfig


class MatriculasConfig(AppConfig):
    name = 'matriculas'
