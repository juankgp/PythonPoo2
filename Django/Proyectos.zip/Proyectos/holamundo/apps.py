from django.apps import AppConfig


class HolamundoConfig(AppConfig):
    name = 'holamundo'
