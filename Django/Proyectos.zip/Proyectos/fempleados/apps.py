from django.apps import AppConfig


class FempleadosConfig(AppConfig):
    name = 'fempleados'
