from django.contrib import admin
from fempleados.models import *
# Register your models here.
admin.site.register(Empleados)

admin.site.register(Prestamos)

admin.site.register(Departamentos)