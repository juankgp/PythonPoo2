from setuptools import setup

setup(name='nombre',version='1.0.0',packages=['nombre']),
entry_points={

    'console_scripts': ['nombre=nombre.__main:main']

}