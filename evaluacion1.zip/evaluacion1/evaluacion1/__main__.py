#from .inventario_funciones import 

def mostrar_menu():

    print('1. Determinar el costo de matrícula')
    print('2. Registar materias ')
    print('3. Valido Opción')
    print('0. Salir')

  


def main():
    while True: 
        try:
            mostrar_menu()
            opcion =int(input('Digite la opción: '))
            if 0 <= opcion <= 5:
                break
            else: 
                print ('La opción debe estar entre 1 y 5')
        except ValueError:
                    print()
                    print('Error: Debe digitar un numero entero valido')

    if opcion == 1:
              
            print("Opcion 1")
            nombres=input('Ingrese los nombres para la factura : ')
                 

    if opcion == 2: 
        print("Opcion 2")

    if opcion == 3:
           print("Opcion 3")
            

if __name__ == '__main__':
    main()