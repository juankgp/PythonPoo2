    #valide e incorpore el codigo a la opcion 3 del menu        
            
            numeros = tuple([2, 4, 6,8,10,12,14,16])
            print('Cantidad de elementos de la tupla:', len(numeros))
            print('Contenido:'; numero)

            print('Operaciones o métodos que provee la clase `tuple`:'
            colores = ('Matemáticas', 'Matemáticas', 'Ofimática', 'Programación', 'Redes', 'Contabilidad', 'Redes')
            print(colores.count('Matemáticas'))
           
           