from setuptools import setup

setup(name='evaluacion1',version='1.0.0',packages=['evaluacion1']),
entry_points={

    'console_scripts': ['evaluacion1=evaluacion1.__main:main']

}